<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'media_jwplayer', language 'vi', version '3.11'.
 *
 * @package     media_jwplayer
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['appearanceconfig'] = 'Ngoại hình';
$string['aspectratio'] = 'Tỉ lệ cạnh';
$string['defaultposter'] = 'Mặc định poster';
$string['defaultposterdesc'] = 'Mặc định hình ảnh poster dùng với video.';
$string['displayfixed'] = 'Cố định';
$string['displayfixedwidth'] = 'Chiều rộng cố định';
$string['displaymode'] = 'Hiển thị trạng thái';
$string['displayresponsive'] = 'Phản hồi';
$string['downloadbutton'] = 'Nút tải về';
$string['downloadbuttondesc'] = 'Thêm nút tải về vào thanh điều khiển';
$string['emptytitle'] = 'Cho phép tiêu đề trống';
$string['enabledevents'] = 'Truy tìm các sự kiện';
$string['enabledextensions'] = 'Kích hoạt các mở rộng';
$string['errornotconfigured'] = 'Cấu hình người chơi chưa hoàn thiện, Xin hãy kiểm tra các cài đặt.';
$string['galabel'] = 'Nhãn sự kiện';
$string['general'] = 'Chung';
$string['googleanalyticsconfig'] = 'Phân tích Google';
$string['licensekey'] = 'Mật khẩu giấy phép';
